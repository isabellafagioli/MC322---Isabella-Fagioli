* teste01: Movimento horizontal.
* teste02: Movimento horizontal e vertical.
* teste03: Comando inválido de movimento para source.
* teste04: Comando inválido de movimento diagonal.
* teste05: Comandos inválidos de source fora do tabuleiro e target fora do tabuleiro.
* teste06: Comandos inválidos de source sem peça e target com peça.
* teste07: Comandos inválidos de ausência de peça intermediária e mais de uma peça intermediária.
* teste08: Vencendo o jogo!
